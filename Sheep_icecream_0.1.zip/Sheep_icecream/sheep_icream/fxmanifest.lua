fx_version 'adamant'

game 'gta5'
lua54 'yes'

author 'SheepMapping'

this_is_a_map 'yes'

files {
    'timecycle_mods_vx.xml'
}

data_file 'TIMECYCLEMOD_FILE'  'timecycle_mods_vx.xml'

