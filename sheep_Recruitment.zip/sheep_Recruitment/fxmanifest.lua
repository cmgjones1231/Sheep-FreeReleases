fx_version 'cerulean'
game 'gta5'

author 'Sheep'
version '1.0.0'


data_file 'DLC_ITYP_REQUEST' 'stream/Trailer_001.ytyp'